import React from 'react';
function App() { return (<div>Welcome to HF Strategic Companies</div>); }
export default App;